
const express = require('express');
const path = require('path');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Serve frontend
app.use(express.static(path.join(__dirname, 'public')));

// Sample API
app.get('/api/itinerary', (req, res) => {
  const { budget='mid' } = req.query;
  const plans = {
    budget: ["Street food crawl", "Public transport city tour"],
    mid: ["City museum", "Local restaurant"],
    luxury: ["Private guided tour", "Fine dining"]
  };
  res.json({ items: plans[budget] || plans['mid'] });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Server running on port " + PORT));
