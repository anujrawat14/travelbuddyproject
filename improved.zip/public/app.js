
document.getElementById('generate').addEventListener('click', async () => {
  const budget = document.getElementById('budget').value;
  const res = await fetch('/api/itinerary?budget=' + budget);
  const data = await res.json();

  const container = document.getElementById('results');
  container.innerHTML = '';
  data.items.forEach(item => {
    const el = document.createElement('div');
    el.className = 'card';
    el.textContent = item;
    container.appendChild(el);
  });
});
